using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform player;  // El transform del jugador
    public Vector3 offset;    // Offset para la cámara

    void LateUpdate()
    {
        transform.position = player.position + offset; // Aplicar el offset
        transform.LookAt(player); // Hacer que la cámara mire al jugador
    }
}

