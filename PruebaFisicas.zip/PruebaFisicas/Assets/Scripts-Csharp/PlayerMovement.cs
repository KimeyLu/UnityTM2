using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    public float speed = 5f;

    void Update()
    {
        // Movimiento basado en el acelerómetro
        Vector3 movement = new Vector3(Input.acceleration.x, 0, Input.acceleration.z);
        transform.Translate(movement * speed * Time.deltaTime);
        
        // Rotación basada en el giroscopio
        if (SystemInfo.supportsGyroscope)
        {
            Gyroscope gyro = Input.gyro;
            gyro.enabled = true;
            transform.rotation = Quaternion.Euler(0, gyro.attitude.eulerAngles.y, 0);
        }
    }
}
